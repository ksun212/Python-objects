sphinx-apidoc -f -P -E -M -o . ../ ../z3 ../tests ../unittests ../setup.py ../frontend
