import package
x = package.x