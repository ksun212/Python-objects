a = float()
b = float(1)
c = float("123")
d = float(1.0)

e = int()
f = int(1)
g = int(1.5)
h = int("123")
i = int("123", 2)

x = input()
y = input("what's your name?")

# a := float
# b := float
# c := float
# d := float
# e := int
# f := int
# g := int
# h := int
# i := int
# x := str
# y := str
