x = [1, 2, 3]

if not x["string"]:
    pass

# unsat