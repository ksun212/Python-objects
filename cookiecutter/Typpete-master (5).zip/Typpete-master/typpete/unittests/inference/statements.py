i = 0
j = 0
for x in [1, 2, 3]:
    L1 = [5, 6, 7, 8]
    L2 = [9, 10, 7, 12]
    for i in [0, 1, 2, 3]:
        for j in [0, 1, 2, 3]:
            if L1[i] == L2[j]:
                n = L1[i]


# L1 := List[int]
# L2 := List[int]
# i := int
# j := int
