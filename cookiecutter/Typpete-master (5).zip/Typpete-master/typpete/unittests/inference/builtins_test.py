a = abs(1)
b = bin(1)
b = b + "2"
c = all([1, 2])
d = chr(1)
d = d + ""
e = complex()
f = dir()
h, i = divmod(c, 2.0)
hh = h
ii = i
j = float(b)
k = hash(j)
l = int(j)
m = str(l)
f[l]
f[k]

# b := str
# d := str
# f := List[str]
# k := int
# l := int
