x = [1, 2, 3]

append(x, 2)

# throws NameError