x = 1
a = [1, 2, 3][x]

x += 2.0

# unsat