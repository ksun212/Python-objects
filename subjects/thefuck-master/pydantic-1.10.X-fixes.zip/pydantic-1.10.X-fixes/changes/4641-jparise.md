Allow dict schemas to have both `patternProperties` and `additionalProperties`
