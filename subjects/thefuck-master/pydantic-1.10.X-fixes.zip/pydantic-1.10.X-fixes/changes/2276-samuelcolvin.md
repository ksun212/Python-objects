Reduce the size of binary wheels.
