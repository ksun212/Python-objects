# Pending Changes

This directory contains files describing changes to pydantic since the last release.

If you're creating a pull request, please add a new file to this directory called
`<pull request or issue id>-<github username>.md`. It should be formatted as a single paragraph of markdown

The contents of this file will be used to update `HISTORY.md` before the next release.
