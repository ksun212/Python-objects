Fix `GenericModel` with `Callable` param raising a `TypeError`
