Fix `schema` and `schema_json` on models where a model instance is a one of default values.
