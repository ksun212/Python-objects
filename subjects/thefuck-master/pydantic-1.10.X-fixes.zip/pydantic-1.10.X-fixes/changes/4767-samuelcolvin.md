Add Jina AI to sponsors on docs index page.
