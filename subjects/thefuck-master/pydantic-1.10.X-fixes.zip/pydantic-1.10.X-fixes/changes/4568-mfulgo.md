Fixes error passing None for optional lists with `unique_items`
