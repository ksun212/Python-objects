Correct `dataclass_transform` keyword argument name from `field_descriptors` to `field_specifiers`
